(function ($) {
	"use strict";

    // -------------------------------------------------------------
    // Main slider
    // -------------------------------------------------------------
    $('.slider-active').owlCarousel({
        loop:true,
        dots:false,
        nav:true,
        autoplayTimeout:3000,
        autoplayHoverPause:true,
        autoplay:true,
        animateIn: 'fadeIn',
        animateOut: 'fadeOut',
        mouseDrag: false,
        smartSpeed:2000,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:1
            },
            1000:{
                items:1
            }
        }
    })

    // -------------------------------------------------------------
    // Service slider
    // -------------------------------------------------------------
$('.service-slider-active').owlCarousel({
    loop:true,
    dots:true,
    nav:false,
    autoplayTimeout:3000,
    autoplayHoverPause:true,
    autoplay:true,
    animateIn: 'fadeIn',
    animateOut: 'fadeOut',
    mouseDrag: false,
    smartSpeed:2000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})

    // -------------------------------------------------------------
    // Client slider
    // -------------------------------------------------------------
$('.client-active').owlCarousel({
    loop:true,
    dots:true,
    margin: 20,
    nav:false,
    autoplayTimeout:3000,
    autoplayHoverPause:true,
    autoplay:true,
    animateIn: 'fadeIn',
    animateOut: 'fadeOut',
    mouseDrag: false,
    smartSpeed:2000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:6
        }
    }
})

    // -------------------------------------------------------------
    // Product Details slider
    // -------------------------------------------------------------
$('.details-img').owlCarousel({
    loop:true,
    dots:true,
    margin: 20,
    nav:false,
    autoplayTimeout:4000,
    autoplayHoverPause:true,
    autoplay:true,
    mouseDrag: false,
    smartSpeed:2000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})


    // -------------------------------------------------------------
    // slider range start
    // -------------------------------------------------------------
    if ($.fn.slider) {
        $(function() {
            $("#slider-range").slider({
                range: true,
                min: -100,
                max: 589,
                values: [5, 389],
                slide: function(event, ui) {
                    $("#amount").val("$" + ui.values[0] + " - $" + ui.values[1]);
                }
            });
            $("#amount").val("$" + $("#slider-range").slider("values", 0) + " - $" + $("#slider-range").slider("values", 1));
        });
    }


}(jQuery));	